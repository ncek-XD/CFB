import os
os.system('python .jalan.py')