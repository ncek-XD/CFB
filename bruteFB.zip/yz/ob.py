import os
import sys
import zlib
import time
import base64
import marshal
import py_compile
import rich,random,re
from rich import print as prints
from rich.table import Table as tab
from rich.console import Console as sol
from rich.panel import Panel as nel
Z2 = "[#000000]" # HITAM
M2 = "[#FF0000]" # MERAH
H2 = "[#00FF00]" # HIJAU
K2 = "[#FFFF00]" # KUNING
B2 = "[#00C8FF]" # BIRU
U2 = "[#AF00FF]" # UNGU
N2 = "[#FF00FF]" # PINK
O2 = "[#00FFFF]" # BIRU MUDA
P2 = "[#FFFFFF]" # PUTIH
J2 = "[#FF8F00]" # JINGGA
A2 = "[#AAAAAA]" # ABU-ABU
bc = '[bold cyan]'
acakrich=random.choice([Z2,H2,K2,B2,U2,N2,O2,P2,J2,A2])
hapus  = '[/]'
if sys.version_info[0]==2:
    _input = "raw_input('%s')"
elif sys.version_info[0]==3:
    _input = "input('%s')"
else:
    sys.exit("\n Your Python Version is not Supported!")


zlb = lambda in_ : zlib.compress(in_)
b16 = lambda in_ : base64.b16encode(in_)
b32 = lambda in_ : base64.b32encode(in_)
b64 = lambda in_ : base64.b64encode(in_)
mar = lambda in_ : marshal.dumps(compile(in_,'<x>','exec'))

def banner(): # Program Banner
    prints(nel("""
.----. .----. .----.
/  {}  \| {}  }| {_   SIMPLE OBF By: NCEK
\      /| {}  }| |   
 `----' `----' `-'
"""))

def menu():
    prints(nel(f'\t\t\tPython Encrypt'))
    lp=nel("""[01] Encrypt Marshal\r      [09] Encrypt Marshal,Zlib\n[02] Encrypt Zlib\r         [10] Encrypt Marshal,Base16\n[03] Encrypt Base16\r       [11] Encrypt Marhsal,Base32\n[04] Encrypt Base32\r       [12] Encrypt Marshal,Base64\n[05] Encrypt Base64\r       [13] Encrypt Marshal,Zlib,B16\n[06] Encrypt Zlib,Base16\r  [14] Encrypt Marshal,Zlib,B32\n[07] Encrypt Zlib,Base32\r  [15] Encrypt Marshal,Zlib,B64\n[08] Encrypt Zlib,Base64\r  [16] Simple Encode""")
    sol().print(lp)

class FileSize: # Gets the File Size
    def datas(self,z):
        for x in ['Byte','KB','MB','GB']:
            if z < 1024.0:
                return "%3.1f %s" % (z,x)
            z /= 1024.0
    def __init__(self,path):
        if os.path.isfile(path):
            dts = os.stat(path).st_size
            print(" [-] Ukuran file : %s\n" % self.datas(dts))
# FileSize('rec.py')

# Encode Menu
def Encode(option,data,output):
    loop = int(eval(_input % " [-] Encrypt berapa lapis? : "))
    if option == 1:
        xx = "mar(data.encode('utf8'))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('marshal').loads(__[::-1]);"
    elif option == 2:
        xx = "zlb(data.encode('utf8'))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('zlib').decompress(__[::-1]);"
    elif option == 3:
        xx = "b16(data.encode('utf8'))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('base64').b16decode(__[::-1]);"
    elif option == 4:
        xx = "b32(data.encode('utf8'))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('base64').b32decode(__[::-1]);"
    elif option == 5:
        xx = "b64(data.encode('utf8'))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('base64').b64decode(__[::-1]);"
    elif option == 6:
        xx = "b16(zlb(data.encode('utf8')))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('zlib').decompress(__import__('base64').b16decode(__[::-1]));"
    elif option == 7:
        xx = "b32(zlb(data.encode('utf8')))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('zlib').decompress(__import__('base64').b32decode(__[::-1]));"
    elif option == 8:
        xx = "b64(zlb(data.encode('utf8')))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));"
    elif option == 9:
        xx = "zlb(mar(data.encode('utf8')))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__[::-1]));"
    elif option == 10:
        xx = "b16(mar(data.encode('utf8')))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('marshal').loads(__import__('base64').b16decode(__[::-1]));"
    elif option == 11:
        xx = "b32(mar(data.encode('utf8')))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('marshal').loads(__import__('base64').b32decode(__[::-1]));"
    elif option == 12:
        xx = "b64(mar(data.encode('utf8')))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('marshal').loads(__import__('base64').b64decode(__[::-1]));"
    elif option == 13:
        xx = "b16(zlb(mar(data.encode('utf8'))))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b16decode(__[::-1])));"
    elif option == 14:
        xx = "b32(zlb(mar(data.encode('utf8'))))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b32decode(__[::-1])));"
    elif option == 15:
        xx = "b64(zlb(mar(data.encode('utf8'))))[::-1]"
        heading = "#Obfuscate By NCEK\n#https://github.com/ncek-xd/Obf\n#SAYANGI DATA HP ANDA!\n_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));"
    else:
        sys.exit("\n Invalid Option!")
    
    for x in range(loop):
        try:
            data = "exec((_)(%s))" % repr(eval(xx))
        except TypeError as s:
            sys.exit(" TypeError : " + str(s))
    with open(output, 'w') as f:
        f.write(heading + data)
        f.close()

# Special Encode
def SEncode(data,output):
    for x in range(5):
        method = repr(b64(zlb(mar(data.encode('utf8'))))[::-1])
        data = "exec(__import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(%s[::-1]))))" % method
    z = []
    for i in data:
        z.append(ord(i))
    sata = "_ = %s\nexec(''.join(chr(__) for __ in _))" % z
    with open(output, 'w') as f:
        f.write("exec(str(chr(35)%s));" % '+chr(1)'*10000)
        f.write(sata)
        f.close()
    py_compile.compile(output,output)

# Main Menu
def MainMenu():
    try:
        banner()
        menu()
        try:
            option = int(eval(_input % " [-] Pilihanmu : "))
        except ValueError:
            sys.exit("\n Pilihan invalid !")
        if option > 0 and option <= 17:
            if option == 17:
                sys.exit("\n Terima kasih telah menggunakan script ini")
        else:
            sys.exit('\n Pilihan invalid !')
        try:
            file = eval(_input % " [-] Nama File : ")
            data = open(file).read()
        except IOError:
            sys.exit("\n File Tidak Ada!")
        
        output = file.lower()
        if option == 16:
            SEncode(data,output)
        else:
            Encode(option,data,output)
        print("\n [-] Berhasil Encrypt File %s" % file)
        print(" [-] Tersave dengan nama file %s" % output)
        FileSize(output)
    except KeyboardInterrupt:
        time.sleep(1)
        sys.exit()

if __name__ == "__main__":
    os.system("clear")
    MainMenu()
